package com.model;

public class T_img {
	private int model_id;
	private String model_name;
	private String phone_color;
	private String img_main;
	private String img_front;
	private String img_reverse;
	private String img_side;
	private String img_reside;
	public int getModel_id() {
		return model_id;
	}
	public void setModel_id(int model_id) {
		this.model_id = model_id;
	}
	public String getModel_name() {
		return model_name;
	}
	public void setModel_name(String model_name) {
		this.model_name = model_name;
	}
	public String getPhone_color() {
		return phone_color;
	}
	public void setPhone_color(String phone_color) {
		this.phone_color = phone_color;
	}
	public String getImg_main() {
		return img_main;
	}
	public void setImg_main(String img_main) {
		this.img_main = img_main;
	}
	public String getImg_front() {
		return img_front;
	}
	public void setImg_front(String img_front) {
		this.img_front = img_front;
	}
	public String getImg_reverse() {
		return img_reverse;
	}
	public void setImg_reverse(String img_reverse) {
		this.img_reverse = img_reverse;
	}
	public String getImg_side() {
		return img_side;
	}
	public void setImg_side(String img_side) {
		this.img_side = img_side;
	}
	public String getImg_reside() {
		return img_reside;
	}
	public void setImg_reside(String img_reside) {
		this.img_reside = img_reside;
	}
	public T_img(int model_id, String model_name, String phone_color, String img_main, String img_front,
			String img_reverse, String img_side, String img_reside) {
		super();
		this.model_id = model_id;
		this.model_name = model_name;
		this.phone_color = phone_color;
		this.img_main = img_main;
		this.img_front = img_front;
		this.img_reverse = img_reverse;
		this.img_side = img_side;
		this.img_reside = img_reside;
	}
	public T_img() {
		super();
	}
	@Override
	public String toString() {
		return "T_img [model_id=" + model_id + ", model_name=" + model_name + ", phone_color=" + phone_color
				+ ", img_main=" + img_main + ", img_front=" + img_front + ", img_reverse=" + img_reverse + ", img_side="
				+ img_side + ", img_reside=" + img_reside + "]";
	}
}
