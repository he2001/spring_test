package com.model;

public class T_good_version {
	private int version_id;
	private String memory_version;
	private int price;
	public int getVersion_id() {
		return version_id;
	}
	public void setVersion_id(int version_id) {
		this.version_id = version_id;
	}
	public String getMemory_version() {
		return memory_version;
	}
	public void setMemory_version(String memory_version) {
		this.memory_version = memory_version;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public T_good_version(int version_id, String memory_version, int price) {
		super();
		this.version_id = version_id;
		this.memory_version = memory_version;
		this.price = price;
	}
	public T_good_version() {
		super();
	}
	@Override
	public String toString() {
		return "T_good_version [version_id=" + version_id + ", memory_version=" + memory_version + ", price=" + price
				+ "]";
	}
}
